// src/app/user.service.spec.ts


import { HttpClient, HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { TaskService } from './task.service';
import { MessageService } from './message.service';
import { Task } from './task';
import { async, fakeAsync } from '@angular/core/testing';
import { assert } from 'console';

let httpClientSpy: { get: jasmine.Spy };
let messageService : MessageService;
let taskService: TaskService;

/****************** getTaskes ************************** */
beforeEach(() => {
  // TODO: spy on other methods too
  httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
  taskService = new TaskService(<any> httpClientSpy,messageService);
});

it('should return expected taskes (HttpClient called once)', () => {
  const expectedHeroes: Task[] =
  [
    {"description":"Task3","id":3,"priority":"Medium","status":"A"},
 {"description":"Task1","id":1,"priority":"Low","status":"A"},
 {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"},

 {"description":"Task4","id":4,"priority":"Medium","status":"A"},
 {"description":"Task5","id":5,"priority":"Low","status":"A"},
 {"description":"Task6","id":6,"priority":"Medium","status":"Not Started"}
   ];

  httpClientSpy.get.and.returnValue(expectedHeroes);

  taskService.getTask(1).subscribe(
    taskes => expect(taskes).toHaveBeenCalled,
    fail
  );
  expect(httpClientSpy.get).toEqual(6, 'one call');
});

it('should return an error when the server returns a 404', () => {
  const errorResponse = new HttpErrorResponse({
    error: 'test 404 error',
    status: 404, statusText: 'Not Found'
  });

  httpClientSpy.get.and.returnValue(async(()=>{errorResponse; }));

  taskService.getTaskes().subscribe(
    taskes => fail('expected an error, not taskes'),
    error  => expect(error.message).toContain('test 404 error')
  );
});

/****************** getTask(1) ************************** */
beforeEach(() => {
    // TODO: spy on other methods too
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    taskService = new TaskService(<any> httpClientSpy,messageService);
  });
  
  it('should return expected taskes (HttpClient called once)', () => {
    const expectedHeroes: Task[] =
    [
      {"description":"Task3","id":3,"priority":"Medium","status":"A"},
   {"description":"Task1","id":1,"priority":"Low","status":"A"},
   {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"},
  
   {"description":"Task4","id":4,"priority":"Medium","status":"A"},
   {"description":"Task5","id":5,"priority":"Low","status":"A"},
   {"description":"Task6","id":6,"priority":"Medium","status":"Not Started"}
     ];
  
    httpClientSpy.get.and.returnValue(expectedHeroes);
  
    taskService.getTask(1).subscribe(
      taskes => expect(taskes).toHaveBeenCalled(),
      fail
    );
    expect(httpClientSpy.get.calls).toEqual({"description":"Task1","id":1,"priority":"Low","status":"A"}, 'one call');
  });
  
  it('should return an error when the server returns a 404', () => {
    const errorResponse = new HttpErrorResponse({
      error: 'test 404 error',
      status: 404, statusText: 'Not Found'
    });
  
    httpClientSpy.get.and.returnValue(async(()=>{errorResponse; }));
  
    taskService.getTask(1).subscribe(
      taskes => fail('expected an error, not taskes'),
      error  => expect(error.message).toContain('test 404 error')
    );
  });

  /****************** deleteTask(1) ************************** */
beforeEach(() => {
    // TODO: spy on other methods too
    httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
    taskService = new TaskService(<any> httpClientSpy,messageService);
  });
  
  it('should return expected taskes (HttpClient called once)', () => {
    const expectedHeroes: Task[] =
    [
      {"description":"Task3","id":3,"priority":"Medium","status":"A"},
   {"description":"Task1","id":1,"priority":"Low","status":"A"},
   {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"},
  
   {"description":"Task4","id":4,"priority":"Medium","status":"A"},
   {"description":"Task5","id":5,"priority":"Low","status":"A"},
   {"description":"Task6","id":6,"priority":"Medium","status":"Not Started"}
     ];
  
    httpClientSpy.get.and.returnValue(expectedHeroes);
  
    taskService.deleteTask(1).subscribe(
      taskes => expect(taskes).toHaveBeenCalled(),
      fail
    );
    !expect(httpClientSpy.get.calls).toContain({"description":"Task1","id":1,"priority":"Low","status":"A"}, 'one call');
    
  });
  
  it('should return an error when the server returns a 404', () => {
    const errorResponse = new HttpErrorResponse({
      error: 'test 404 error',
      status: 404, statusText: 'Not Found'
    });
  
    httpClientSpy.get.and.returnValue(async(()=>{errorResponse; }));
  
    taskService.getTask(1).subscribe(
      taskes => fail('expected an error, not taskes'),
      error  => expect(error.message).toContain('test 404 error')
    );
  });

  /****************** updae(1) ************************** */
beforeEach(() => {
  // TODO: spy on other methods too
  httpClientSpy = jasmine.createSpyObj('HttpClient', ['get']);
  taskService = new TaskService(<any> httpClientSpy,messageService);
});

it('should return expected taskes (HttpClient called once)', () => {
  const expectedHeroes: Task[] =
  [
    {"description":"Task3","id":3,"priority":"Medium","status":"A"},
 {"description":"Task1","id":1,"priority":"Low","status":"A"},
 {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"},

 {"description":"Task4","id":4,"priority":"Medium","status":"A"},
 {"description":"Task5","id":5,"priority":"Low","status":"A"},
 {"description":"Task6","id":6,"priority":"Medium","status":"Not Started"}
   ];

  httpClientSpy.get.and.returnValue(expectedHeroes);

  taskService.updateTask({"description":"Task3","id":3,"priority":"Medium","status":"A"}).subscribe(
    taskes => expect(taskes).toHaveBeenCalled(),
    fail
  );
  !expect(httpClientSpy.get.calls).toContain({"description":"Task1","id":1,"priority":"Low","status":"AA"}, 'one call');
  
});

it('should return an error when the server returns a 404', () => {
  const errorResponse = new HttpErrorResponse({
    error: 'test 404 error',
    status: 404, statusText: 'Not Found'
  });

  httpClientSpy.get.and.returnValue(async(()=>{errorResponse; }));

  taskService.updateTask({"description":"Task3","id":3,"priority":"Medium","status":"A"}).subscribe(
    taskes => fail('expected an error, not taskes'),
    error  => expect(error.message).toContain('test 404 error')
  );
});