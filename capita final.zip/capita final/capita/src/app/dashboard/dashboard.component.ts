import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: [ './dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {
  heroes: Task[] = [];

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    this.getTaskes();
  }

  getTaskes(): void {
    this.taskService.getTaskes()
      .subscribe(heroes => this.heroes = heroes.slice(1, 5));
  }
}


