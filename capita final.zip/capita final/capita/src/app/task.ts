export interface Task {
  priority : string;
  id: number;
  description: string;
  status : string;
}


