import { Task } from './task';

export const TASKS: Task[] = [
  // {"description":"Task3","id":3,"priority":"Medium","status":"A"},
  // {"description":"Task1","id":1,"priority":"Low","status":"A"},
  // {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"}
];


