import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
import { Task } from './task';

@Injectable({
  providedIn: 'root',
})
export class InMemoryDataService implements InMemoryDbService {
  createDb() {
    const taskes = [
     {"description":"Task3","id":3,"priority":"Medium","status":"A"},
  {"description":"Task1","id":1,"priority":"Low","status":"A"},
  {"description":"Task2","id":2,"priority":"Medium","status":"Not Started"},

  {"description":"Task4","id":4,"priority":"Medium","status":"A"},
  {"description":"Task5","id":5,"priority":"Low","status":"A"},
  {"description":"Task6","id":6,"priority":"Medium","status":"Not Started"}
    ];
    return {taskes};
  }

  // Overrides the genId method to ensure that a task always has an id.
  // If the taskes array is empty,
  // the method below returns the initial number (11).
  // if the taskes array is not empty, the method below returns the highest
  // task id + 1.
  genId(taskes: Task[]): number {
    return taskes.length > 0 ? Math.max(...taskes.map(task => task.id)) + 1 : 11;
  }
}


