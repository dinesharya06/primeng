import { Component, OnInit } from '@angular/core';

import { Task } from '../task';
import { TaskService } from '../task.service';

@Component({
  selector: 'app-taskes',
  templateUrl: './tasks.component.html',
  styleUrls: ['./tasks.component.css']
})
export class TasksComponent implements OnInit {
  taskes: Task[];

  constructor(private taskService: TaskService) { }

  ngOnInit() {
    this.getTaskes();
  }

  getTaskes(): void {
    this.taskService.getTaskes()
    .subscribe(taskes => this.taskes = taskes);
  }

  add(description: string,priority: string ,status : string): void {
    description = description.trim();
    if (!description) { return; }
    this.taskService.addTask({ description,priority,status } as Task)
      .subscribe(task => {
        this.taskes.push(task);
      });
  }

  delete(task: Task): void {
    this.taskes = this.taskes.filter(h => h !== task);
    this.taskService.deleteTask(task).subscribe();
  }

}

