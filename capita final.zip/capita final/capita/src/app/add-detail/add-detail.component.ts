import { Component, OnInit } from '@angular/core';
import { Task } from '../task';
import { TaskService } from '../task.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-add-detail',
  templateUrl: './add-detail.component.html',
  styleUrls: ['./add-detail.component.css']
})
export class AddDetailComponent implements OnInit {

  taskes: Task[];

  constructor(private taskService: TaskService,private location: Location) { }

  ngOnInit() {
    this.getTaskes();
  }

  getTaskes(): void {
    this.taskService.getTaskes()
    .subscribe(taskes => this.taskes = taskes);
  }

  add(description: string,priority: string ,status : string): void {
    description = description.trim();
    if (!description) { return; }
    this.taskService.addTask({ description,priority,status } as Task)
      .subscribe(task => {
        this.taskes.push(task);
      });
      this.location.back();
  }
  goBack(): void {
    this.location.back();
  }
y
  

}


